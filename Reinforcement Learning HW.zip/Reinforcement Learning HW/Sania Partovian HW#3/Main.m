function[V]=Main()

gamma=0.9;     %discount rate

L=4;           %size of board

Vp=zeros(L);   %Initial value of board
Vp(1,1)=100;   %Value for goal
Vp(L,L)=100;   %Value for goal
Vc=Vp;         %Synchronous update


%some parameteres for convergence:
MAX_N_ITER = 1000;
Counter = 0;
theta = 1e-4;
% a uniform policy
pol_pi=0.25;
k=1;
text(10,210-60*(k),['k= ',num2str(k-1)],'color','r','FontWeight','bold','FontSize',16);
ShowResults(Vc,k);
rep=1;

while (Counter <= MAX_N_ITER )
    delta=0;
    %update states in the orderone indexes matrices
    %state (1,1) and (4,4) are terminal states
    
    for i=1:L,
        for j=1:L,
            if(  (i==1 && j==1)  ||   (i==L && j==L)   )
                continue;
            end
                        
            v     =  Vp(i,j);  %currnt value
            S     =0.0;        %new value
            % loop over each possible actions (up,doen,right,left);
            % action = up
            if (i==1)
                
                s  =  s  +   pol_pi*(  -1  +  gamma*Vp(i,j) );
                
            elseif(   i==2 && j==1)
                
                s  =  s  +   pol_pi*(  0  +  gamma*Vp(i-1,j) );
               
            else
                
                s  =  s  +   pol_pi*(  -1  +  gamma*Vp(i-1,j) );
            end
          % action = down       
          if( i==L )
          
             s  =  s  +   pol_pi*(  -1  +  gamma*Vp(i,j) );
                
            elseif(   i==2 && j==1)
                
                s  =  s  +   pol_pi*(  0  +  gamma*Vp(i-1,j) );
               
            else
                
                s  =  s  +   pol_pi*(  -1  +  gamma*Vp(i-1,j) );
          end    
                    
          
           % action = Right
           if( j==L )
               
               
               s  =  s  +   pol_pi*(  -1  +  gamma*Vp(i,j) );
            elseif(   j==L-1 && i==L)
                
                
                s  =  s  +   pol_pi*(  0  +  gamma*Vp(i,j+1) );
           else
                
                
                s  =  s  +   pol_pi*(  -1  +  gamma*Vp(i,j+1) );
           end
            
          % action = left
          if( j==1 )
               
               
               s  =  s  +   pol_pi*(  -1  +  gamma*Vp(i,j) );
            elseif(   j==2 && i==1)
                
                
                s  =  s  +   pol_pi*(  0  +  gamma*Vp(i,j-1) );
           else
                
                
                s  =  s  +   pol_pi*(  -1  +  gamma*Vp(i,j-1) );
          end
          
          Vc(i,j) = s;
          delta=max(  [  delta,  abs(  v-s)  ]  );
        end
    end
    Vp=Vc;
    Counter=Counter+1;
    

    end
end
