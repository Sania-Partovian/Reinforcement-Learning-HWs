clear all;
v = zeros(6,1);
Q = zeros(6,2);
policy = ones(6,2)/2;
policy(1,:)= 0 ;
policy(6,:)= 0 ;
epsilon = 0.1 ;
gamma = 0.5;
counter = 1;
beta = 0.5;
alpha = 0.4;
step = 0 ;
test = zeros(50,1);
while(counter<50)
    state = 2;
    flag = 0;
    while(flag~=1)
        step = step + 1;
        test(counter) = test(counter) + 1; 
        e = rand;
        sv = policy(state,:);
        if(e < sv(1))
            action = 1;
            col = 1;
        elseif (e < sv(1) + sv(2))
            action = -1;
            col = 2 ;
        end
        
        p = rand ;
        if(p > 0.8 && p <= 0.95)
            action = - action;
        elseif p > 0.95
            action = 0;
        end
        
        r = 0;
        prev_state = state ;
        state = state + action ;
        if(state == 1)
            r = 1;
            flag = 1;
        elseif(state == 6)
            r = 5;
            flag = 1;
        end
        
        if flag == 1
            Q(prev_state,col) = r;
            v(prev_state) = r;
        else
            Q(prev_state,col) = Q(prev_state,col) +  alpha * (r + gamma * v(state)-Q(prev_state,col));
            v(prev_state) = v(prev_state) + beta *(r + gamma * v(state) - v(prev_state));
            
            [o,ac]= max( Q(prev_state,:));
            policy(prev_state,:) = epsilon /2;
            policy(prev_state,ac) = 1 - epsilon + epsilon / 2;
            epsilon = epsilon - 0.0003;
        end
    end
    counter = counter + 1;
end