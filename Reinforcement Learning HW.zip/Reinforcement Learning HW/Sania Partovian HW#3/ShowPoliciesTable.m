function ShowPoliciesTable((x,y,w,VC)
     x2=x+w;
     y2=y+w;
     dw=w/4;
     x1=linspace(x,x2,5);
     y1=linspace(y,y2,5);
     figure(1);
     for i=1:length(x1)
         line([x1(1),x1(end)],[y1(i),y1(i)]);
         hold on;
     end
     
     for i=1:length(x1)
         line([x1(i),x1(i)],[y1(1),y1(end)]);
         hold on;
     end
     rectangle('Position',[x,y2-dw,dw,dw],'Facecolor','y');
     rectangle('Position',[x2-dw,y,dw,dw],'Facecolor','y');
     x=x+dw/2;
     y=y+w-1/2+dw;
     for i=1:4
         for j=1:4
             if ( (i*j~=1) && (i*j~=16)   )
                 if (i==1)
                     V(1)=-inf;
                     V(3)=VC(i+1,j);
                 elseif(i==4)
                     V(1)=VC(i-1,j);
                     V(3)=-inf;
                 else
                     V(1)=VC(i-1,j);
                     V(3)=VC(i+1,j);
                 end
                 if (j==1)
                     V(4)=-inf;
                     V(2)=VC(i,j+1);
                 elseif(j==4)
                     V(2)=-inf;
                     V(4)=VC(i,j-1);
                 else
                     V(2)=VC(i,j+1);
                     V(4)=VC(i,j-1);
                 end
                 
                 ShowArrow((j-1)*dw+x,y-(i-1)*dw,V)
             end
         end
     end
end