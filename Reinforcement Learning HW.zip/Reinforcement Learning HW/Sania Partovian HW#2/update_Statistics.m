function update_Statistics(st)

   rectangle('position',[40,-250,650,220],'facecolor','w','edgecolor','w');
   text(100,-50,'high');
   text(40,-70,,'------------------------');
   text(50,-90,['#count:  ',num2str(st.High.Count)],'fontsize',16,'fontweight','bold');
   text(50,-120,['#wait:   ',num2str(st,High,Wait)],'fontsize',16,'fontweight','bold');
   text(50,-150,['#Search:   ',num2str(st,High,Search)],'fontsize',16,'fontweight','bold');
   
   text(150,-180,['#CurrentReward:   ',num2str(st,CurrentReward)],'fontsize',16,...
                 'fontweight','bold','color','g');
   text(150,-210,['#TotalReward:   ',num2str(st,TotalReward)],'fontsize',16,...
                 'fontweight','bold','color','r');
             
   text(500,-50,'Low');
   text(440,-70,'--------------------');
   text(450,-90,['#Count:   ',num2str(st,Low.Count)],'fontsize',16,'fontweight','bold');
   text(450,-120,['#Wait:   ',num2str(st,Low.Wait)],'fontsize',16,'fontweight','bold');
   text(450,-150,['#Search:   ',num2str(st,Low.Search)],'fontsize',16,'fontweight','bold');
   text(450,-180,['#Recharge:   ',num2str(st,Low.Recharge)],'fontsize',16,'fontweight','bold');
   
end
   