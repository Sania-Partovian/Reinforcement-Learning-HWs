% TD Random walk evaluation value for garbage
Q = zeros(6,2);
gamma = 0.5;
counter = 0;
alpha = 0.5;
bb = 0 ;
policy = ones(6,2)/2;
policy(1,:)=0;
policy(6,:)=0;
epsilon = 0.1 ;
step = 0 ;
while(counter < 50)
    
    state = 2;
    flag = 0;
    e = rand;
    sv = policy(state,:);
    if(e < sv(1))
        action = 1;
        col = 1;
    elseif (e < sv(1) + sv(2))
        action = -1;
        col = 2 ;
    end
    p = rand ;
    if(p > 0.8 && p <= 0.95)
        action = - action;
    elseif p > 0.95
        action = 0;
    end
    
    while(flag~=1)
        step = step + 1 ; 
        
        r = 0;
        sprim = state + action ;
        if(sprim == 1)
            r = 1;
            flag = 1;
        elseif(sprim == 6)
            r = 5;
            flag = 1;
        end        
     
        p1 = rand;
        e = rand;
        sv1 = policy(sprim,:);
        if(e <= sv1(1))
            aprim = 1;
            colprim = 1;
        elseif (e < sv1(1) + sv1(2))
            aprim = -1;
            colprim = 2 ;
        end
        
        if(p1 > 0.8 && p1 <= 0.95)
            aprim = -aprim;
        elseif(p1> 0.95)
            aprim = 0;
        end
        Q(state,col) = Q(state,col) + ...
            alpha * (r + gamma * Q(sprim,colprim)-Q(state,col)); 
        % update policy 
        [o,ac]= max( Q(state,:));
        policy(state,:) = epsilon /2;
        policy(state,ac) = 1 - epsilon + epsilon / 2;
        epsilon = epsilon - 0.0003;    
        
        action = aprim ;
        state = sprim ;
        
    end
    
    bb = [bb step];
    counter = counter + 1;
    step = 0 ;
end