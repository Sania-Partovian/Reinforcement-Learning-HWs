function r=C1RandomWaitSearchRecharge(p1,p2)
      a=rand;
      if a<p1
          r=0;
      elseif a<p2
          r=1;
      else
          r=2;
      end
end