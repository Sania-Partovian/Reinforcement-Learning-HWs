%TD Random walk evaluation value for garbage 
v = zeros(6,1);
counter = 0;
gamma = 0.5 ; 
alpha = 1;
while(counter<5)
    state = 3;
    flag = 0;
while(flag~=1)
    action = rand ;
    if(action<0.5)
        action = -1;
    else
        action = 1;
    end
    p = rand ; 
    if(p > 0.8 && p <= 0.95)
      action = - action;
    elseif p > 0.95
        action = 0;
    end
    r = 0;
    prev_state = state ;
     state = state + action ;
     if(state == 1)
         r = 1;
         flag = 1;
     elseif(state == 6)
         r = 5;
         flag = 1;
     end
     v(prev_state) = v(prev_state) + alpha *(r + gamma * v(state) - v(prev_state));
end
counter = counter + 1;
end