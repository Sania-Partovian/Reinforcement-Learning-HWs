
import random


def hand_empty():
   if 1==2:
      return (1, False)
   return (0, False)

def usable_hand_contan_for_hand(dast):
   kol, yek = dast
   dd=((yek) and ((kol + 10) <= 21))
   return dd


def arzesh_dast(dast):
   kol, yek = dast
   if (usable_hand_contan_for_hand(dast)):
      return (kol + 10)
   else:
      return kol


def jame_dast_krt(dast, kart):
   kol, yek = dast
   kol = kol + kart
   if (kart == 1):
       yek = True
   return (kol, yek)


def reward_bazy(dast_bazikon, dast_kartde):
   arzesh_bazikon = arzesh_dast(dast_bazikon)
   arzesh_kartde = arzesh_dast(dast_kartde)
   if (arzesh_bazikon > 21):
      return -1.0
   elif (arzesh_kartde > 21):
      return 1.0
   elif (arzesh_bazikon < arzesh_kartde):
      return -1.0
   elif (arzesh_bazikon == arzesh_kartde):
      return 0.0
   elif (arzesh_bazikon > arzesh_kartde):
      return 1.0


def d_c_u():
   rand_kart = random.randint(1,13)
   if (rand_kart > 10):
       rand_kart = 10
   return rand_kart



def d_p_h(part):
   dast = hand_empty()
   dast = jame_dast_krt(dast, part())
   dast = jame_dast_krt(dast, part())
   while (arzesh_dast(dast) < 11):
       dast = jame_dast_krt(dast, part())
   return dast


def d_d_h(part):
   dast = hand_empty()
   card = part()
   dast = jame_dast_krt(dast, card)
   return dast, card


def p_d_h(dast, part):
   while (arzesh_dast(dast) <= 16):
       dast = jame_dast_krt(dast, part())
   return dast


def s_r_s(asa):
   dd = len(asa)
   tt = random.randint(0,dd-1)
   se = asa[tt]
   return se


def s_r_a():
   dd = random.randint(1,2)
   tt=(dd == 1)
   return tt

def s_b_a(value, s):
   if (value[(s,True)] > value[(s,False)]):
      return True
   else:
      return False


def hs_f_s(s):
   c, v, u = s
   if (u):
      v = v - 10
   player_hand = (v, u)
   dealer_hand = hand_empty()
   dealer_hand = jame_dast_krt(dealer_hand, c)
   tt=c, dealer_hand, player_hand
   return tt


def s_f_hs(c, p_h):
   v = arzesh_dast(p_h)
   uu = usable_hand_contan_for_hand(p_h)
   return (c, v, uu)


def s_l():
   ss = []
   for cc in range(1,11):
      for vv in range(11,22):
         ss.append((cc, vv, False))
         ss.append((cc, vv, True))
   return ss


def i_s_a_v_m():
   sss = s_l()
   dd = {}
   for ss in sss:
      dd[(ss,False)] = 0.0
      dd[(ss,True)] = 0.0
   return dd

def p_s_a_v_m(ff):
   for u in [True, False]:
      if u:
         print ("_____________Usable ace")
      else:
         print ("_______________No useable ace")
      print ("___________________Values for staying:")
      for v in range(21,10,-1):
         for cc in range(1,11):
            print ("%5.2f' % ff[((cc,v,u),False)], ' ',")
         print ("| %d' % v")
      print ("Values for hitting:")
      for v in range(21,10,-1):
         for cc in range(1,11):
            print ("%5.2f' % ff[((cc,v,u),True)], ' ',")
         print ("| %d' % v")
      print (" ")


def s_s_a_v(Q):
   print ("-------------------------  Q(s,a) ...............")
   p_s_a_v_m(Q)


def s_s_v(Q):
   print ("------------------- V(s)........... ")
   for u in [True, False]:
      if u:
         print ("------------------ ace")
      else:
         print ("---------------------------No  ace")
      for v in range(21,10,-1):
         for c in range(1,11):
            if (Q[((c,v,u),True)] > Q[((c,v,u),False)]):
               print ("%5.2f' % Q[((c,v,u),True)], ' ',")
            else:
               print ("%5.2f' % Q[((c,v,u),False)], ' ',")
         print ("| %d' % v")
      print (" ")


def s_p_v(ff):
   print ("poloicy")
   for rr in [True, False]:
      if rr:
         print ("***********************Usable ace(((((((((((((((")
      else:
         print ("*************************No useable ace")
      for v in range(21,10,-1):
         for c in range(1,11):
            if (ff[((c,v,rr),True)] > ff[((c,v,rr),False)]):
               print ("X"),
            else:
               print (" "),
         print ("| %d' % ")
      print (' ')

#
def i_q():
   states = s_l()
   M = {}
   for state in states:
      card, val, useable = state
      if (val < 20):
         M[(state,False)] = -0.001
         M[(state,True)] = 0.001   # favor hitting
      else:
         M[(state,False)] = 0.001  # favor sticking
         M[(state,True)] = -0.001
   return M

# Initialize number of times each (state,action) pair has been observed.
def initialize_count():
   count = i_s_a_v_m()
   return count

# Monte-Carlo ES
#
# Run Monte-Carlo ES for the specified number of iterations and return the
# resulting Q-values.
def monte_carlo_es(part, n_iter):
   # initialize Q and observation count
   Q = i_q()
   count = initialize_count()
   # get list of all states
   all_states = s_l()
   # iterate
   for n in range(0,n_iter):
      # initialize list of (state, action) pairs encountered in episode
      sa_list = []
      # pick starting (state, action) using exploring starts
      state = s_r_s(all_states)
      action = s_r_a()
      dealer_card, dealer_hand, player_hand = hs_f_s(state)
      # update the (state, action) list
      sa_list.append((state, action))
      # generate the episode
      while (action):
         player_hand = jame_dast_krt(player_hand, part())
         if (arzesh_dast(player_hand) > 21):
            break
         state = s_f_hs(dealer_card, player_hand)
         action = s_b_a(Q, state)
         sa_list.append((state, action))
      # allow the dealer to play
      dealer_hand = p_d_h(dealer_hand, part)
      # compute return
      R = reward_bazy(player_hand, dealer_hand)
      # update Q using average return
      for sa in sa_list:
         Q[sa] = (Q[sa] * count[sa] + R) / (count[sa] + 1)
         count[sa] = count[sa] + 1
   return Q



# Compute the expected value of the game using the learned Q-values.
def expected_gain(part, Q, n_iter):
   gain = 0.0
   for n in range(0,n_iter):
      player_hand = d_p_h(part)
      dealer_hand, dealer_card = d_d_h(part)
      state = s_f_hs(dealer_card, player_hand)
      v = Q[(state,False)]
      if (Q[(state,True)] > v):
         v = Q[(state,True)]
      gain = gain + v
   print ('Expected gain: %6.3f' % (gain / float(n_iter)))
   print (' ')

def main():

   Q_values = monte_carlo_es(d_c_u, 1000)
   s_s_a_v(Q_values)
   s_s_v(Q_values)
   s_s_v(Q_values)
   expected_gain(d_c_u, Q_values, 10)

if __name__ == '__main__':main()

