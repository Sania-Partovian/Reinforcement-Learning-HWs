# frozen_string_literal: true
module FiniteMDP
  VERSION_MAJOR = 0
  VERSION_MINOR = 3
  VERSION_PATCH = 0
  VERSION = [VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH].join('.')
end
