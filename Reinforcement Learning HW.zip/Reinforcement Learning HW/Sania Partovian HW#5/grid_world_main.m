%%% Main script for Grid World with Bellman and Optimal bellman

%% Initializing
clear;clc;
N=4;T=10;gamma = 0.9;    % discount rate

v = zeros(N);  % State-value function
vn = v;          % New State-value function
delta=1;
actions = [1,0;-1,0;0,1;0,-1]; % 1=Down 2=Up 3=Right 4=Left
A=[1,1];Ap= [1,1];rA=0;   % special state A
B=[4,4];Bp=[4,4];rB=0;    % special state B
N=4;    % 4*4 size
while delta > 0.001
    for i = 1:N
        for j=1:N
            p=[i j];
            vn(i,j)=0;
            for k = 1:4      % 1=Down 2=Up 3=Right 4=Left
                %                 [pn,r] =GWenviroment(p,k);
                
                if k==1 && p(1)==N                 % Last Line
                    pn=p;r=0;
                elseif p==A                        % special State A
                    pn=Ap;r=rA;
                elseif p==B                        % special State B
                    pn=Bp;r=rB;
                elseif p(1)==1 && k==2             % First Line
                    pn=p;r=0;
                elseif k==3 && p(2)==N             % Last Column
                    pn=p;r=0;
                elseif k==4 && p(2)==1             % First Column
                    pn=p;r=0;
                else
                    pn = p + actions(k,:);r=-1;  %Other Cells
                end
                vn(i,j) = 0.25*(r+gamma*v(pn(1),pn(2)))+vn(i,j);
            end
        end
    end
    delta=max(max(abs(v - vn)));
    v=vn;
end
%% Displaying Results:
disp('State-value function for equiprpbable random policy & gamma=0.9 ');
disp('Bellman iterative solution with delta=0.001:');
disp (vn);

