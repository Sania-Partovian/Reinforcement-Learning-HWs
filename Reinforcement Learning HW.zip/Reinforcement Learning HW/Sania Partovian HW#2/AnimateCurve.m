function AnimateCurve(curve,color,linewidth)
    x=curve(1,1); %first coordinate
    y=curve(1,2);  %first coordinate
     hold on;
    p = plot(x(1),y(1),'o','MarkerFaceColor,'g','MarkerSize',15)
    



    [n,~]=size(curve);
    for i=1:n
        p.XData = curve(1,1);
        p.YData = curve(1,2);

    pause(0.04);
    end
p.XData = 0;
p.YData = 0;
end