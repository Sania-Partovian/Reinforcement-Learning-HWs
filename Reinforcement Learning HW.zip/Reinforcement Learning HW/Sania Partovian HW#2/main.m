function main()


%C1=Low State
C1.self.pos=[380,300-183,77,77];
C1.self.edgecolor='b';
C1.self.fillcolor='w';
C1.self.linewidth=3;

C1.Search.x=413+zeros(1,20);
C1.Search.y=linspace(190,250,20);
C1.Search.linewidth=3;
[C1.Search.ToHigh.x,C1.Search.ToHigh.y]=GetCurve([413,377,262,194,163],...
                                                 [245,289,274,240,184]);

C1.Search.ToHigh.x=flip(C1.Search.ToHigh.x);
C1.Search.ToHigh.y=flip(C1.Search.ToHigh.y);
C1.Search.ToLow.x=[413,420,434,450,462,480,502,503,502,495,486,469,450];
C1.Search.ToLow.y=[245,267,279,284,285,279,250,239,223,203,189,176,171];

C1.Wait.linewidth=3;
C1.Wait.x=[413+zeros(1,20),413,420,434,450,462,480,502,503,502,495,486,469,450];
C1.Wait.y=[linspace(118,64,20),60,33,21,16,15,21,50,61,77,97,111,124,129];

C1.Recharge.x=linspace(380,177,50);
C1.Recharge.y=150+zeros(1,50);
C1.Recharge.Linewidth=3;

%C2=High State    

C2.self.pos=[100,300-183,77,77];
C2.self.edgecolor='r';
C2.self.fillcolor='w';
C2.self.linewidth=3;

C2.Search.x=145+zeros(1,20);
C2.Search.y=linspace(115,64,20);
C2.Search.linewidth=3;


C2.Search.ToHigh.x=[145,138,130,119,104,89,75,65,58,54,55,59,64,73,84,100,110];
C2.Search.ToHigh.y=[65,42,33,26,23,23,29,38,50,66,84,97,109,122,130,137,139];

[C2.Search.ToLow.x,C2.Search.ToLow.y]=GetCurve([145,163,182,272,346,385,398],...
                                               [68,29,22,29,55,87,130]);


C2.Wait.linewidth=3;
C2.Wait.x=[145+zeros(1,20),140,133,127,120,109,98,84,71,65,59,56,54,55,59,66,78,90,109];
C2.Wait.y=[linspace(190,250,20),263,270,275,279,283,284,282,275,269,260,251,238,222,209,194,181,173,169];

ShowCircle(C1.self.pos,C1.self.edgecolor,C1.self.fillcolor,C1.self.linewidth);
ShowCircle(C2.self.pos,C2.self.edgecolor,C2.self.fillcolor,C2.self.linewidth);


line(C1.Search.x,C1.Search.y,'LineWidth',C1.Search.linewidth);
line(C1.Wait.x,C1.Wait.y,'LineWidth',C1.Wait.linewidth);
line([470,450],[129,130],'LineWidth',C1.Search.linewidth);
line([460,450],[120,130],'LineWidth',C1.Search.linewidth);

line(C1.Recharge.x,C1.Recharge.y,'LineWidth',C1.Recharge.linewidth);
line([200,180],[154,150],'LineWidth',C1.Search.linewidth);
line([199,180],[144,150],'LineWidth',C1.Search.linewidth);

line(C1.Search.ToHigh.x,C1.Search.ToHigh.y,'LineWidth',C1.Search.linewidth);
line([162,163],[202,183],'LineWidth',C1.Search.linewidth);
line([172,163],[201,183],'LineWidth',C1.Search.linewidth);

line(C1.Search.ToLow.x,C1.Search.ToLow.y,'LineWidth',C1.Search.linewidth);
line([467,450],[180,172],'LineWidth',C1.Search.linewidth);
line([470,450],[171,172],'LineWidth',C1.Search.linewidth);

line(C1.Wait.x,C1.Wait.y,'LineWidth',C1.wait.linewidth);

line(C2.Search.x,C2.Search.y,'LineWidth',C2.Search.linewidth);
line(C2.Wait.x,C2.Wait.y,'LineWidth',C2.Wait.linewidth);
line([93,111],[179,168],'LineWidth',C1.Search.linewidth);
line([91,111],[168,168],'LineWidth',C1.Search.linewidth);

line(C2.Search.ToHigh.x,C2.Search.ToHigh.y,'LineWidth',C2.Search.linewidth);
line([90,109],[140,140],'LineWidth',C1.Search.linewidth);

text(318,171,'Rechearge');
text(217,171,'1,0');
text(495,20,'1, R Wait');
text(22,15,'\alpha, R Search');
text(255,2,'1- \alpha, R Search');
text(25,290,'1, R Waiat');
text(495,20,'1, R Waiat');
text(507,265,'\beta, R Waiat');
text(193,290,'1- beta, -3');
line(146,57,'Marker','a','MarkerFaceColor','black');
line(327,152,'Marker','a','MarkerFaceColor','black');
line(414,65,'Marker','a','MarkerFaceColor','black');
line(414,251,'Marker','a','MarkerFaceColor','black');

state=2;
C2pWait=0.2;
C2pSearch=1-C2pWait;
C2alpha=0.5;
C2alphaN=1-C2alpha;

C1pWait=0.1;
C1pSearch=0.3;
C1Recharge=1-(C1pSearch+C1pWait);
C1beta=0.5;
C1betaN=1-C1beta;

axis([1,800 ,1,300]);
axis equal;


statistics.Low.Search=0;
statistics.Low.Recharge=0;
statistics.TotalReward=0;
statistics.currentReward=0;

for i=1:100
    update_Statistics(statistics);
    if(state==2)
        update_Statistics(statistics);
        C2.Self.edgecolor='r';
        C1.Self.edgecolor='b';
        C2.Self.fillcolor='r';
        C1.Self.fillcolor='w';
        ShowCircle(C1.self.pos,C1.self.edgecolor,C1.self.fillcolor);
        ShowCircle(C2.self.pos,C2.self.edgecolor,C2.self.fillcolor);
        text(116,158,'High');
        text(393,157,'Low');
        pause(0.4);
        r=C2RandomWaitSearch(C2pWait);
        if (r==1)
            AnimateCurve([C2.Wait.x',C2.Wait.y'],'r',3);
            statistics.CurrentReward=getReward('wait');
            state=2;
            statistics.High.Count=statistics.High.Count+1;
            statistics.High.Wait=statistics.High.Wait+1;
            statistics.TotalReward=statistics.TotalReward+1;
        else
            AnimateCurve([C2.Search.x',C2.Search.y'],'r',3)
            statistics.CurrentReward=getReward('search');
            statistics.TotalReward=statistics.TotalRewar+1;
            r=C2RandomAlpha(C2alpha);
            statistics.High.Search=statistics.High.Search+1;
            if(r==1) %back to self
                cc
                statistics.High.Count=statistics.High.Count+1;
                state=2;
            else %to Low
                AnimateCurve([C2.Search.ToLow.x',C2.Search.ToLow.y'],'r',3);
                statistics.Low.count=statistics.Low.count+1;
                state=1;
            end
        end
    elseif(state==1)   %   Low State
        update_Statistics(statistics);
        C2.self.edgecolor='b';
        C1.self.edgecolor='r';
        C2.self.fillcolor='w';
        C1.self.fillcolor='r';
        ShowCircle(C1.self.pos,C1.self.edgecolor,C1.self.fillcolor);
        ShowCircle(C2.self.pos,C2.self.edgecolor,C2.self.fillcolor);
        text(116,158,'High');
        text(395,157,'Low');
        pause(0.6);
        r=C1RandomWaitSearchRecharge(C1pWait,C1pWait,C1pSearch);
        if r==0   % wait
            AnimateCurve([C1.Wait.x',C1.Wait.y'],'r',3);
            statistics.CurrentReward=getReward('wait');
            statistics.TotalReward=statistics.TotalReward+1;
            statistics.Low.Count=statistics.Low.Count+1;
            statistics.Low.Wait=statistics.Low.Wait+1;
            state=1;
        elseif r==1   %Search
            AnimateCurve([C1.Search.x',C1.Search.y'],'r',3);
            statistics.CurrentReward=getReward('search');
            statistics.TotalReward=statistics.TotalReward+1;
            state=1;
        else    % Send to charge [High]
            AnimateCurve([C1.Search.ToHigh.x',C1.Search.ToHigh.y'],'r',3);
            statistics.High.Count=statistics.High.Count+1;
            statistics.Low.Search=statistics.Low.Search+1;
            statistics.CurrentReward=-3;
            statistics.TotalReward=statistics.TotalReward+1;
                    
            state=2;
        end
        else %Recharge
            AnimateCurve([C1.Recharge.x',C1.Recharge.y'],'r',3);
            statistics.CurrentReward=getReward('recharge');
            statistics.TotalReward=statistics.TotalReward+1;
            statistics.High.Count=statistics.High.Count+1;
            statistics.Low.Recharge=statistics.Low.Recharge+1;
            state=2;
        end
     end 
   end           
            
