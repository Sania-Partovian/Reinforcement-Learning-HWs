%TD Random Walk Value Evaluation For Maze
v = zeros(16,1);
ss = 0;aa = 0;
counter = 0;
alpha = 0.6;
state = 6 ;
prev = 0;
while counter  < 200
    state = 6 ;
    flag = 0;
    
    while flag ~= 1
        ss = [ss ;  state];
        action = randi([1,4]); 
        aa = [aa ; action];
        
        [env,sprim,flag,r]=applyAction(state,action);        
        v(state) = v(state) + alpha *(r +  v(sprim) - v(state));
        state = sprim ;
%         state 
%         action
         pause(0.01)
    end
    bb = [ss aa];
    counter = counter + 1;
    counter
end
