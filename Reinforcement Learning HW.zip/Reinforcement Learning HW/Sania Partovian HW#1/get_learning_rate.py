def get_learning_rate(t,MIN_LEARNING_RATE):
    import math
    return max(MIN_LEARNING_RATE, min(0.5, 1.0 - math.log10((t+1)/25)))