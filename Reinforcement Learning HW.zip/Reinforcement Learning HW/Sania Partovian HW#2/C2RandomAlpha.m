function r=C2RandomAlpha(alpha)
     r=rand<alpha;
end