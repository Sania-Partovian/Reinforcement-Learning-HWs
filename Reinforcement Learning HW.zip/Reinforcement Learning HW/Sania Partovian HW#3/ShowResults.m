function ShowResults(Vc,k)
      axis([1,150,1,200]);
      ShowValueTable(20,190-60*k,50,Vc);
      ShowPoliciesTable(90,190-60*k,50,Vc);
      
end