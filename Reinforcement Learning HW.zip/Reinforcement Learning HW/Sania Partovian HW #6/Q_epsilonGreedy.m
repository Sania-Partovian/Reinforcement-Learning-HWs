Q = zeros(6,2);
policy = ones(6,2)/2 ;
policy(1,:)=0;
policy(6,:)=0;
epsilon = 0.1 ;
gamma = 0.5;
alpha = 0.5;
counter = 0;
step = 0 ;
while counter < 50
    flag = 0;
    state = 2;
    while flag ~= 1
        step = step + 1;
    e = rand;
    sv = policy(state,:);
    if(e < sv(1))
        action = 1;
        col = 1;
    elseif (e < sv(1) + sv(2))
        action = -1;
        col = 2 ;
    end       
        p = rand ;
        if(p > 0.8 && p <= 0.95)
            action = - action;
        elseif p > 0.95
            action = 0;
        end
        r = 0;
        
        sprim = state + action ;
        if(sprim == 1)
            r = 1;
            flag = 1;
        elseif(sprim == 6)
            r = 5;
            flag = 1;
        end
        
        % find aprim 
         if(Q(sprim,1) >= Q(sprim,2))
                aprim = 1;
                colprim = 1;
            else
                aprim = -1;
                colprim=2;
            end
         Q(state,col) = Q(state,col) +  alpha * (r + gamma * Q(sprim,colprim)-Q(state,col));
         
         % update policy 
        [o,ac]= max( Q(state,:));
        policy(state,:) = epsilon /2;
        policy(state,ac) = 1 - epsilon + epsilon / 2;
        epsilon = epsilon - 0.0003;  
         state = sprim;
    end
    counter = counter + 1;
end