function [xx,yy]=GetCurve(x,y)
    x0=min(x);
    x1=max(x);
    xx=linspace(x0,x1,50);
    z=polyfit(x,y,3);
    yy=polyval(z,xx);
end