function ShowValuesTable(x,y,w,VC)
    x2=x+w;
    y2=y+w;
    x1=linspace(x,x2,5);
    y1=linspace(y,y2,5);
    figure(1);
    for i=1:length(x1)
        line([x1(1),x1(end)],[y1(i),y1(i)]);
        hold on;
    end
    
    for i=1:length(x1)
        line([x1(i),x1(i)],[y1(1),y1(end)]);
        hold on;
    end
    
    for i=1:4
        s=sprintf('%0.2f',VC(5-i,4));
        text((x1(4)+x1(5))/2.2,(y1(i)+y1(i+1))/2,s,'FontWeight','bold','FontSize',14);
        s=sprintf('%0.2f',VC(5-i,3));
        text((x1(3)+x1(4))/2.2,(y1(i)+y1(i+1))/2,s,'FontWeight','bold','FontSize',14);
        s=sprintf('%0.2f',VC(5-i,2));
        text((x1(2)+x1(3))/2.2,(y1(i)+y1(i+1))/2,s,'FontWeight','bold','FontSize',14);
        s=sprintf('%0.2f',VC(5-i,1));
        text((x1(1)+x1(2))/2.2,(y1(i)+y1(i+1))/2,s,'FontWeight','bold','FontSize',14);
    end
    
end


        