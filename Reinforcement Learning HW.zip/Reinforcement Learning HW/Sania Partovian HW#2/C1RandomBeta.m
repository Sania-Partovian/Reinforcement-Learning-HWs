function r=C1RandomBeta(Beta)
     r=rand<beta;
end