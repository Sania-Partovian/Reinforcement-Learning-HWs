def get_explore_rate(t,MIN_EXPLORE_RATE):
    import math
    return max(MIN_EXPLORE_RATE, min(1, 1.0 - math.log10((t+1)/25)))