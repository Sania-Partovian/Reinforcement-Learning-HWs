clcfunction [Env,nstate,flag,r]=applyAction(state,action)
f = zeros(4,4);
c = 1;
for i=1:4
    for j=1:4
        f(i,j) = c;
        c = c+1;
    end
end
Env = zeros(4,4);
Env(1,1)=10; %terminal
Env(4,4)=10; %terminal
[row,col]=find(f==state);


Env(row,col) = 0;
switch action  
    case 1
        if(row ~= 1) 
            row = row - 1;           
            r = -1;
        else
            r = -200;
        end
        
    case 2
        if(row ~= 4)
            row = row + 1;
            r = -1; 
        else
            r = -200;
        end
        
    case 3
        if(col ~= 1)
            col = col - 1;
            r = -1;
        else
            r = -200;
        end
        
    case 4        
        if(col ~= 4)
            col = col + 1;
            r = -1;
        else
            r = -200;
        end
        Env(row,col) = 2;

       imagesc(Env);
       colormap(jet);
        
end
nstate = (col -1) * 4 + row;
if Env(row,col) == 10
    r = 40;
    flag = 1;
else
    flag = 0;
end
end